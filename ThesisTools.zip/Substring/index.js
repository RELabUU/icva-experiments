var ontology, ontology2;
var ontologyLowerCase, ontologyLowerCase2;
var bpmnconcepts, istarconcepts;
var bpmnconceptsLowerCase, istarconceptsLowerCase;

var model4, model5, model6, model7, model8, model9, model10, model11, model12, model13, model14, model15, model16, model17, model18, model19;
var model4LC, model5LC, model6LC, model7LC, model8LC, model9LC, model10LC, model11LC, model12LC, model13LC, model14LC, model15LC, model16LC, model17LC, model18LC, model19LC;

var counter = 0;
var counter2 = 0;

//Click event for first button (RQ2 part 1)
$('#button').click(function(e) {
  //Split the ontology file for every \n (creating noun chunks)
  var ontologyarray = ontologyLowerCase.split("\n");

  for(var i = 0; i<ontologyarray.length; i++)
  {
    //CHANGE THIS FOR EVERY MODEL TO BE COMPARED
    //CHANGE VARIABLE, SAVE, RELOAD WEB PAGE
    if(model19LC.includes(ontologyarray[i]))
    {
      counter += 1;
    }
  }

  //Alerts how many ontology nouns are present in comparison variable
  alert(counter);
});

//Click event for second button (RQ1)
$('#button2').click(function(e) {
  //Splitting the ontology into nouns
  var ontologyarray2 = ontologyLowerCase2.split(" ");

  for(var i = 0; i<ontologyarray2.length; i++)
  {
    //CHANGE THIS FOR EVERY MODEL TO BE COMPARED
    //CHANGE VARIABLE, SAVE, RELOAD WEB PAGE
    if(istarconceptsLowerCase.includes(ontologyarray2[i]))
    {
      counter2 += 1;
    }
  }

  alert(counter2);
});

//Click event for the third button (RQ2 part 2)
$('#button3').click(function(e) {
  //Splitting ontology into nouns USING THE CORRECT ONTOLOGY STRING
  var ontologyarray = ontologyLowerCase2.split(" ");
  var commonNouns = [];

  for(var i = 0; i<ontologyarray.length; i++)
  {
    //CHANGE THIS FOR EVERY MODEL
    //Creating an array that includes all common nouns
    if(model12LC.includes(ontologyarray[i]))
    {
      commonNouns.push(ontologyarray[i]);
    }
  }

  //Splitting ontology into noun chunks
  var ontologyChunkArray = ontologyLowerCase.split("\n");
  var resultingList = [];

  for(var j = 0; j<ontologyChunkArray.length; j++)
  {
    //Check if the noun chunk is present in the common nouns array
    if(commonNouns.includes(ontologyChunkArray[j]))
    {
      //Add the noun "chunk" to the resulting list
      resultingList.push(ontologyChunkArray[j]);
    }
  }

  //What we have filtered out now are the "chunks" (whether they are singular or multiple nouns)
  //that are not present in the common nouns list.

  //Create an array of unique common nouns
  var uniqueCommon = [];
  $.each(commonNouns, function(i, el){
    if($.inArray(el, uniqueCommon) === -1) uniqueCommon.push(el);
  });

  var percentage = (100/uniqueCommon.length*resultingList.length);
  alert(percentage);
});

//Click event for fourth button (RQ3)
$('#button4').click(function(e) {
  //Splitting Class list into nouns
  var ClassArray = classConceptsLC.split(" ");
  //Splitting comparison model into nouns
  var testArray = model19LC2.split(" ");

  var matchArray = [];

  //Comparing class to model
  for(x = 0; x < ClassArray.length; x++)
  {
    if(testArray.includes(ClassArray[x]))
    {
      matchArray.push(ClassArray[x]);
    }
  }

  //Determining unmatched concepts in both models
  var unmatchClass = (ClassArray.length-matchArray.length);
  var unmatchModel = (testArray.length-matchArray.length);

  var totalUnmatch = (unmatchClass+unmatchModel);

  var totalElements = (totalUnmatch + matchArray.length)

  //Determining the alignment scores
  var alignmentScore = (100/totalElements*matchArray.length);

  alert(alignmentScore);
});

//Click event for fifth button (RQ4)
$('#button5').click(function(e) {
  //Splitting the elements that were rated not useful into noun chunks
  var NotUsefulArray = model18NULC.split("\n");
  var counter = 0;

  for(var z = 0; z < NotUsefulArray.length; z++)
  {
    if(model18LC.includes(NotUsefulArray[z]))
    {
      counter += 1;
    }
  }

  alert(counter);
});



//Concept lists for every model MEANT TO BE SPLIT FOR NOUN CHUNKS

ontology = "ElementLabel\nThesis\nThesis project\nProject\nGraduation project\nMBI Graduation project\nMBI thesis\nMBI thesis project\nFinal thesis project\nSupervisor\nGraduation supervisor\nFirst Supervisor\nSecond Supervisor\nOenI Group member\nDepartment member\nStaff member\nGraduation coordinator\nMBI colloquium coordinator\nInformation science\nMBI\nMBI program\nComputer science\nComputing Science\nIntended Learning outcome\nILO\nLearning outcome\nGraduate school\nGSNS\nMailing list\nChapter\nGraduation request\nShort Proposal\nHoliday\nGraduation\nProject facilitator\nGraduation project facilitator\nCompany\nCompany supervisor\nInternship\nResearch Method\nEnvisaged method\nProposed research method\nResearch approach\nLiterature research protocol\nPhase\nPhase one\nFirst phase\nINFOMMBI1\nProject proposal\nPhase two\nSecond phase\nINFOMMBI2\nSecond part\nFifteen EC\nLiterature review\nRelated work\nRelevant literature\nSystematic literature study\nTwenty-five EC\nGrading\nGrade\nEight months\nColloquium\nMBI Colloquium\nThesis colloquium\nOenI Research Colloquium\nResearch colloquium\nfour EC\nFirst presentation\nSecond presentation\nGoogle calendar\nCalendar\nCum-laude graduation\nCum-laude\nThesis defense\nDefense\nAssessment form\nEvaluation form\nBeamer\nFinal Presentation\nGraduation ceremony\nOfficial ceremony\nDiploma\nAcademiegebouw\nDomplein\nPublication\nScientific paper\nConference publication\nJournal publication\nMBI program coordinator\nMBI student\nUU\nUtrecht University\nOenI Group\nOenI\nOral presentation\nPresentation\nOsiris\nOsiris scripties\nOther lecturer\nParticipation token\nToken\nPart-time thesis\nPart-time job\nSide project\nThesis topic\nTopic\nPre-developed project\nIdeas\nProject ideas\nPrinted copy\nProblem statement\nQuestion\nResearch question\nRetake\nRoom\nScience research project coordinator\nSigned Graduation request\nWork placement agreement\nStandard contract\nSigned work placement agreement\nStudy plan\nThesis report\nThree months\nFive months\nMBI Colloquium presentation\nRegistration\nStudent administration\nResearch plan\nPlan";

ontologyLowerCase = ontology.toLowerCase();

ontology2 = "ElementLabel Thesis Thesis project Project Graduation project MBI Graduation project MBI thesis MBI thesis project Final thesis project Supervisor Graduation supervisor First Supervisor Second Supervisor OenI Group member Department member Staff member Graduation coordinator MBI colloquium coordinator Information science MBI MBI program Computer science Computing Science Intended Learning outcome ILO Learning outcome Graduate school GSNS Mailing list Chapter Graduation request Short Proposal Holiday Graduation Project facilitator Graduation project facilitator Company Company supervisor Internship Research Method Envisaged method Proposed research method Research approach Literature research protocol Phase Phase one First phase INFOMMBI1 Project proposal Phase two Second phase INFOMMBI2 Second part Fifteen EC Literature review Related work Relevant literature Systematic literature study Twenty-five EC Grading Grade Eight months Colloquium MBI Colloquium Thesis colloquium OenI Research Colloquium Research colloquium four EC First presentation Second presentation Google calendar Calendar Cum-laude graduation Cum-laude Thesis defense Defense Assessment form Evaluation form Beamer Final Presentation Graduation ceremony Official ceremony Diploma Academiegebouw Domplein Publication Scientific paper Conference publication Journal publication MBI program coordinator MBI student UU Utrecht University OenI Group OenI Oral presentation Presentation Osiris Osiris scripties Other lecturer Participation token Token Part-time thesis Part-time job Side project Thesis topic Topic Pre-developed project Ideas Project ideas Printed copy Problem statement Question Research question Retake Room Science research project coordinator Signed Graduation request Work placement agreement Standard contract Signed work placement agreement Study plan Thesis report Three months Five months MBI Colloquium presentation Registration Student administration Research plan Plan";

ontologyLowerCase2 = ontology2.toLowerCase();

bpmnconcepts = "BPMN-2\nCheck if courses are completed\nCheck if student has one pending course\nDetermine if student can get exception\nDefine topic\nEnroll in the MBI thesis project\nWrite short proposal\nReview short proposal\nSign short proposal\nFill in workplace agreement\nReview workplace agreement\nSign workplace agreement\nDetermine impact of deviation on wp agreement\nFormalize graduation request\nCheck formalized graduation request\nInform student administration\nCheck formalized graduation request\nSubscribe to mailing list\nWrite long proposal\nReview long proposal\nIf NOT written within 3 months\n> 2 months\nRetake long proposal\nIf NOT written within 3 weeks\nFinalize long proposal\nPerform 1st colloquium presentation\nWrite thesis\n> 8 months\nReview thesis\nWrap-up\n< 8 months\nDetermine if ILOs have been achieved\nNo\nYes\nYes\nNo\nNo\nYes\nProposal not OK\nProposal OK\nAgreement not OK\nAgreement OK\nDeviation needed\nDeviation not needed\nProject outside UU\nProject inside UU\nFGR not OK\nFGR OK\nNot satisfactory\nSatisfactory\nGrade >= 5.5";

bpmnconceptsLowerCase = bpmnconcepts.toLowerCase();

istarconcepts = "iStar-2\nGraduation project facilitator\nStudent\nGraduation supervisor\nGraduation coordinator\nDefine topic\nDefine research project\nThesis topic\nSupervise intern\nThesis topic\nApprove research project\nThesis topic\nThesis topic approved\nSubmit thesis timely\nWrite long proposal\nWrite final manuscript\nGrade student\nGrade\nPrepare graduation\nGood grade for thesis\nWrite a research paper\nSupervise student\nThesis manuscript\nPresent in the colloquium\nGive diploma\nDiploma\nPresentation\nManage colloquium\nD\nD\nD\nD\nD\nD\nAnd\nAnd\nHelp\nD\nD\nAnd\nHelp\nHelp\nD\nD\nD\nD\nD\nD";

istarconceptsLowerCase = istarconcepts.toLowerCase();

classConcepts = "STUDENT MSC PROGRAMME LECTURER DEPARTMENT FACULTY DAILY SUPERVISOR MBI THESIS COURSE GRADING FORM Student number Name Surname Email address Acronym Name SolisID Name Surname Email address Name Dutch Name English Name Dutch Name English Title Name Affiliation Telephone number Email address Title Location Starting date part I Short description Num hours supervision Planning of supervision Agreed student work load Student absence Supervisor absence Presentation plan Lab meeting plan Other activities plan Host organisation Work placement agreement Study plan Additional notes Student signature Student signature date Supervisor signature Supervisor signature date Track coordinator signature Track coordinator signature date Prog coordinator signature Prog coordinator signature date Exam board signature Exam board signature date Number of colloquium tokens Date first colloquium presentation Report part I (long proposal) Part I grade Ending date part I Date second colloquium presentation Report part I (long proposal) Part II grade Ending date part II (defence) Osiris Scripties link Course code Name Description Credits Course website independence in execution of the project independence in writing the report/proposal planning and meeting deadlines communication integrity and responsibility critical and reflective attitude Grade project process Explanation structure context content quality of slides/media presentation skills suitability for audience ability to cope with questions Grade project presentation Explanation structure and clarity of presentation discussion of related work and context completeness and correctness of arguments English usage general appearance Grade project report Explanation quality of the results quantity of the results difficulty of the project Grade project results Explanation Final grade Supervisor signature Second examiner signature";

classConceptsLC = classConcepts.toLowerCase();

model4 = "Utrecht University\nStudent\nExternal company\nSupervisor\nMBI coördinator\nStudent administration\nRoom coördinator\nDecline topic\nSign graduation request\nReject graduation request\nSign workplace agreement\nReview formal graduation request\nApprove formal graduation request\nSolve problems\nReview chosen topic\nApprove topic\nReview graduation request\nArrange room\nReady to start graduation process\nFind a supervisor\nEnroll in colloquium course\nCreate graduation request\nFind a topic\nSign graduation request\nWrite thesis at university\nSign workplace agreement\nChoose project facilitator\nWrite thesis at company\nFormalize graduation request\nEnroll in INFOMMBI1\nExecute Phase 1\nExecute Phase 2\nEnroll in INFOMMBI2\nSet graduation date\nAsk for ECTS\nAsk for room\nDeliver printed copies to supervisors\nAttend graduation ceremony\nPublish thesis at Osiris\nDefense presentation\nProvide assessment form\nAttend 12 colloquia\nPresent thesis during 2 colloquia\nGreduated\nSign workplace agreement";

model4LC = model4.toLowerCase();

model5 = "Student\nRegistrated for thesis\nCourses succesfully completed\nThesis Finished\nWrite Thesis\nGraduation supervisor found\nThesis Started\nGraduation project facilitator found\nDefine Topic\nTopic Chosen\nGraduation Supervisor\nEvaluate Topic\nGraduation Project Facilitator\nThe University\nCompany\nProject\nGraduation project\nThesis Project\nFinished Thesis\nThesis\nFind Graduation Supervisor\nFind/arrange Graduation Project Facilitator\nTopic\nDiscuss topic";

model5LC = model5.toLowerCase();

model6 = "Graduate MBI\nTopic defined\nenroll in colloquium\nThesis project completed\nactive participation\ngraduation request signed by first supervisor\ncreate graduation request\nsign request\nformalized graduation request\nstudy plan\nworkplace agreement\nformalize request\nworkplace agreement signed\nsubscribe to mailing list\nfinish part 1 in 3 months\nfinish part 2 in 5 months\nfirst presentation\nsecond presentation\nmake proposal\ncreate report\nset date for graduation\nrecieve MBI colloquium\nfirst supervisor\nagree with topic\nsign request\nO&I group\ngraduation coordinator\ncheck request and study plan\nMBI programme coordinator\ncheck request and study plan\nscience research project coordinator\nsign workplace agreement\ncompany supervisor\nsign workplace agreement\nMBI colloquium coordinator\nDefine topic\nrequest signed\nrequest and study plan checked\nrequest and study plan checked\nagreement signed\nagreement signed";

model6LC = model6.toLowerCase();

model7 = "Student\nMBI Graduated\nPhase 1 Completed\nPhase 2 Completed\nMBI Colloquium Completed\n12 Colloquia attended\n2 Presentations Given\nMake Title\nMake Research Plan\nMake Literature Review\nCan lead to interesting scientific insights\nGive Final Presentation\nMake Scientific Paper\nBi-weekly O&I research colloquium Attended\nSet-up Completed\nEnroll in MBI Colloquium\nGet Graduation Requests\nFormalize Graduation Request\nSubscribe to the Mailing List\nObtain Workplace Agreement\nRelated Work,Graduation Supervisor\nThesis Chapters Reviewed\nReview Thesis Topic\nDepartment Member\nGraduation Project Facilitator\nGraduation School of Natural Sciences\nMake Thesis Report\nDefine a Topic";

model7LC = model7.toLowerCase();

model8 = "University\nCompany\nSupervisor\nStudent\nStart MBI thesi\nFind topic\nEnroll in colloquium\nConfirm meeting\nCompany or university\nArrange meeting with supervisor\nMessage company\nArrange supervisor\nConfirm topic with company\nWrite graduation request\nSign request\nSign request\nFormalise request\nSubscribe to mailing\nSubmit thesis proposal\nCheck proposal against GSNS form\nMark proposal\nVoldaan\nNiet voldaan\nInform student of retake\nNiet voldaan + retake niet voldaan\nInform student of pass\nInform student of failure\nVoldaan niet voldaan\nWrite retake\nAttend colloquium meetings\nGive first presentation\nStart second phase\nConduct research\nWrite report\nWrite thesis proposal\nGive presentation\nyes\nGrade\nno\nWrite scientific paper\nSubmit reports and papers\nAttend colloquium meetings\nCheck attendance\nAttendance status\n12 meetings\nInform student of fail\n12 meetings\nGrade report\nInform student of grade\n4 6\n4 OR 6 and retake 6\n6\nWrap up project\nWrite retake\nFailure\nGraduate\n8.5\nGraduate cum laude\nWrap up project and publish paper\nDecide on topic\n";

model8LC = model8.toLowerCase();

model9 = "Student\nGraduate\nPass Courses\nComplete Colloqia requirement\nComplete MBI Thesis Project\nThesis\nWriting Thesis\nDefining topic\nComplete First Phase\nComplete Second Phase\nEnrolling in osiris\nAttending Colloqia\nDefine Research Plan\nPerforming Research\nShort Proposal\nDoing literature study\nPresent Thesis\nPresent Project proposal\nDefending Thesis\nGet date\nGet room\nEvaluating every presentation\nAttending graduation ceremony\nPublicate scientific paper\nComplete work-placement agreementSupervisor\nSupervising thesis project\nDo research\nGrade Thesis project\nFill in assesment form\nGSNS\nMonitoring student progress\nExternal supervisor\nAsking updates about student\nFind common interest\nDiscussing\nThesis\nAgree on thesis project";

model9LC = model9.toLowerCase();

model10 = "Departement member\nSupervise\nThesis grading\nwithin 8 months\nCoordinator\nCheck proposal\nStaff members\nStudents\nThesis projects\nGraduate\nChoose thesis subject\nEnroll colloquium\ngraduation request\nWorkplace agreement\nWorkplace agreement\nThesis\nResearch plan\nLiterature review\nTitle\nPresentation 2\nPresentation1\nMeetings\nParticipate 12 meetings\nAssemble proposal document\nStudy plan\nGrade thesis\nMeet";

model10LC = model10.toLowerCase();

model11 = "Student\nGraduated\nSet up completed\nFirst phase completed\nSecond phase completed\nWrap up completed\nDefine a topic\nEnroll MBI colloquium\nWrite graduation request\nFormalize graduation request\nSubscribe to mailing list\nUndefined form\nSigned graduation request\nStudy plan\nSigned workplace agreement\nDefine research method\nConduct scientific survey\nResearch plan designed and developped\nRelevant literature understood\nGive colloquium presentation\nWell timed\nExecute research design plan\nGive colloquium presentation\nGive final presentation\nSuccesful\nSet date\nAsk MBI colloquium\nArrange room and beamer\nDeliver copies to supervisors\nPrinted copies\nDefend thesis\nPublish thesis\nAttend graduation ceremony\nCum laude completed\nObtain grade higher than 8.5\nFirst supervisor\nGraduation request template\nGrade project\nGraduation supervisor\nMBI programme coordinator\nGraduation request signed\nWrite graduation request\nSign graduation request\nCheck proposal\nCheck proposal\nComunicate results\nApprove thesis\nApprove thesis\nAssesment form";

model11LC = model11.toLowerCase();

model12 = "Student\nGraduated\nProposal Phase succesfully completed\nThesis phase successfully completed\nProject idea selected\nSelect project idea\nOriginal idea\nbe MBI enrolled\nMBI program successfully completed\nSigned graduation request\nWrite graduation request\nWork placement agreement signed\nSign work placement agreement\nHigh grade\nProposal written\nWrite proposal\nContains required elements\nRelevant literature recorded\nFind relevant literature\nPresentation done\nCreate presentation\nWithin 3 month timeframe\nCum laude graduation\nSecond presentation done\nResearch done\nThesis written\nProject idea\nDo research\nResults\nThesis approved\nLearning goals\nUniversity\nGraduation supervisor\nProject facilitator\nSign work placement agreement\nGraduation coordinator\nSign work placement agreement\nPredeveloped idea\nCompany proposed idea\nPropose project idea\nSend graduation request\nCoordinator-signed agreement\nCompany-signed agreement\nApprove thesis";

model12LC = model12.toLowerCase();

model13 = "Student\nUtrecht University\nExternal project facilitator\nDecline received\nLook at staff members webpages\nLook at staff members Google Scholar pages\nLook at MBI Grad Projects website\nTalk to graduation coordinator\nSelect supervisor\nArrange meetings with staff members\nSend request to supervisor\nEnroll in MBI colloquium\nAcceptation received\nWrite proposal document\nSend supervisor sign request\nModify proposal document\nSign proposal document\nDeline received\nSigned proposal document received\nArrange work placement\nFind department member\nApply for internship at company\nSupervisor\nInternal project facilitator\nAssess student\nDecline student\nNotify student about decline\nNotify student about acceptation\nAccept student\nRequest received\nSign request received\nAssess proposal document\nAccept proposal document\nDecline proposal document\nNotify student about decline\nSign proposal document\nSend proposal document back\nApplication received\nAssess student\nAccept student\nDecline student\nInvite for interview\nSend decline notification";

model13LC = model13.toLowerCase();

model14 = "Student\nGraduation achieved\nSet up phase completed\nSecond phase completed\nFirst phase completed\nEnrolled in colloquium\nGraduation request formalized\nMailing list subscribed\nDefine first topic\nEnroll in colloquium\nWrite graduation request\nAssemble\nSign\nFormalize graduation request\nDefine research method\nConduct literature survey\nComplete proposal\nCreate title\nCreate research plan\nUniversity\nCompany\nGraduation coordinator\nCheck proposal\nCheck studyplan\nProject facilitator\nFirst supervisor\nAgree with first topic\nSign graduation request\nAssemble\nSign\nDepartment of Information and Computing Sciences\nMBI programme coordinator\nCheck studyplan\nCheck proposal\nFirst topic defined\nGraduation request fulfilled\nShort proposal assembled\nShort porposal signed\nStudyplan\nProposal";

model14LC = model14.toLowerCase();

model15 = "Student\nFirst Supervisor\nArrange meeting with Staff Members\nArrange meeting with Graduation Coordinator\nApproach organisation for internship\nDefine a Topic\nEnroll in MBI Colloquium\nCreate Short Proposal with superviser\nSign Short Proposal\nSend Short Proposal to Superviser\nRecieve Signed Short Proposal\nFill in and sign Workplace Agreement\nFormalise Graduation Request\nSubscribe to mailing list\nParticipate in Colloquiums\nLiterary Research\nAsk Supervisor for permission to present\nCreate slides for presentation\nSend slides to supervisor for approval\nPresent in Colloquim\nReceive approval\nStudent needs to redo project proposal\nCourses successfully completed\nStudent can start phase 2\nParticipate in Colloquiums\nStart phase 2\nAsk supervisor for permission to present\nCreate presentation slides\nAsk for approval of slides\nReceive permission to present\nPresent in colloquium\nContinue Phase 2\nCreate final presentation\nSet Date for presentation\nDate picked\nAsk for Colloquium EC\nArrange room and beamer\nDeliver printed copies of thesis to supervisors\nGive final presentation\nPublish Thesis\nAttend Graduation Ceremony\nAgree on Topic\nign Short Proposal\nJudge if student is ready to present\nDisprove presenting\nApprove presenting\nJudge presentation slides\nSlides disproved\nAgree on judgement with second supervisor\nCommunicate results to GSNS\nStudent has failed part 1\nStudent has passed part 1\nSlides approved\nJudge if student is ready to present\nDisprove presenting\nApprove presenting\nJudge Slides\nSlides disproved\nSlides approved\nJudge Presentation\nPresentation was sufficient\nPresentation was insufficient\nWith second supervisor, agree or disagree on date\nDate not agreed on\nDate agreed on\nJudge final presentation\nStudent has failed and can't retake\nStudent has failed and can retake\nStudent has passed";

model15LC = model15.toLowerCase();

model16 = "Student\nSupervisor\nCoordinators\nStart\nFind supervisor\nSettle on topic\nChoose topic\nMBI Colloquium enrollment\nWrite graduation request\nSign graduation request\nSend graduation request\nReceive signed graudation request\nConduct project within UU\nConduct project outside UU\nSign workplace agreement\nGet workplace agreement signed\nSubmit graduation request\nSubscribe to the mailing list\nDefine research method\nConduct a scientific survey of relevant literature\nGive presentation in the MBI Colloquium\nExecute research method\nSecond MBI Colloquium presentation\nFinal MBI Colloquium presentation\nHave thesis approved\nSet graduation date/time and check with supervisors\nAsk for MBI Colloquium EC\nArrange location and beamer\nDeliver printed copy of thesis to supervisors\nSend out thesis assessment form\nDefend thesis during presentation\nPublish thesis on Osiris\nParticipate in graduation ceremony\nAgree on topic\nSign graduation request\nGive feedback to student\nReceive proposal and study plan\nCheck study plan\nCheck proposal\nIssues found\nNo issues found\nStudent notified\nPass on data to student administration";

model16LC = model16.toLowerCase();

model17 = "MBI Graduation Project\nStudent\nFirst supervisor\nGraduation coordiantor(s)\nMBI Coordinator\nSecond supervisor\nDefine topic\nSure about topic\nContact graduation coordinator\nFind suiting topic\nFind supervisor\nYes\nNo\nEnroll MBI colloquiem\nStart graduation request\nWrite graduation request\nSign 1st signature\nSign 2nd signature\nSupport student\nSend to coordinators\nCheck graduation request\nAgreed?\nCheck proposal graduation request\nAgreed?\nSubscribe mailing list\nStart phase one\nDefine research method\nConduct scientific survey\nGive 1st presentation\nGrade presentation\nShare judgement\nAgreed?\nInform approval\nYes\nNo\nInform rejection\nCreate GSNS form\nSend to GSNS\nSent to student\nReceive feedback 1st presentation\nWork on thesis\nGive 2nd presentation\n4 months\nContinue thesis\nFinish thesis report\nGive final presentation\nGive 1st grade";

model17LC = model17.toLowerCase();

model18 = "Utrecht University\nSupervisor(s)\nStudent\nMBI colloquium coordinator\nGeraldine LeeBeek\nFind Supervisor\nGive topic\nReview topic\nDecline topic and student\nGive appraisal\nApprove\nReceive appraisal\nStart phase one\nDefine research method\nDefine scientific survey of the literature\nSend to supervisor for remarks\nReview student work of phase one\nMark phase one as Voldaan\nOrganize Phase one Presentations\nSend review to student\nReceive review\nMake presentation Phase one\nWrite down feedback of presentation\nGive Phase one presentation\nGive results/feedback of presentation to student\nReceive presentation feedback\nStart phase two\nStart working on thesis research\nGather results\nOrganize presentation phase two\nMake presentation phase two\nGive presentation phase 2\nWrite down feedback of presentation\nGive results/feedback to student\nReceive feedback\nResume thesis research\nGather results\nStart organizing final presentation\nMake final presentation\nPerform final presentation\nWrite down feedback of presentation\nGive results/feedback to student\nReceive feedback\nWrite final report\nHand in final report\nGrade final report\nSend grade to student\nFinish phase two\nReceive grade of report\nDeclare day of graduation\nAgreement of date by supervisors\nSend room/beamer reservation\nAgreement\nNo agreement\nSend request MBI Colloquium\nReceive request\nReceive reservation\nInform student\nGrant 4 EC to student\nReceive message";

model18LC = model18.toLowerCase();

model19 = "Utrecht University\nCompany\nStudent\nFirst Supervisor\nScience Research Project Coordinator\nMBI programme coordinator\nGraduation coordinator\nGraduation supervisor\nStart\nComplete courses\nFind supervisor\nSure about topic?\nYes\nNo\nArrange meeting with graduation coordinator\nDefine topic\nAgree on topic\nEnroll in colloquium\nWrite graduation request\nSend graduation request to first supervisor\nSign graduation request\nSign graduation request\nFind workspace\nWorkspace outside Utrecht University?\nNo\nFill in work placement agreement\nSend agreement\nSign agreement\nSign agreement\nFill in formalisation form\nCheck proposal\nCheck proposal\nAny issues?\nYes\nPass data to Student Administration\nSubscribe to mailinglist\nNo\nStart first phase\nDefine research method\nConduct scientific survey\nPresent phase 1 in MBI colloquium\nGrade phase 1\nFill in GSNS form\nGive feedback\nGrade phase 1\nFill in GSNS form\nGive feedback\nAgree on grading\nAgree on grading\nCommunicate grading to GSNS\nStart second phase\nExecute research\nPresent in MBI colloquium\nMake final presentation\nGrade second phase\nGrade second phase\nPass second phase\nSupervisor\nSign agreement";

model19LC = model19.toLowerCase();



//Concept lists for every model MEANT TO BE SPLIT FOR NOUNS

bpmnconcepts2 = "BPMN-2 Check if courses are completed Check if student has one pending course Determine if student can get exception Define topic Enroll in the MBI thesis project Write short proposal Review short proposal Sign short proposal Fill in workplace agreement Review workplace agreement Sign workplace agreement Determine impact of deviation on wp agreement Formalize graduation request Check formalized graduation request Inform student administration Check formalized graduation request Subscribe to mailing list Write long proposal Review long proposal If NOT written within 3 months > 2 months Retake long proposal If NOT written within 3 weeks Finalize long proposal Perform 1st colloquium presentation Write thesis > 8 months Review thesis Wrap-up < 8 months Determine if ILOs have been achieved No Yes Yes No No Yes Proposal not OK Proposal OK Agreement not OK Agreement OK Deviation needed Deviation not needed Project outside UU Project inside UU FGR not OK FGR OK Not satisfactory Satisfactory Grade >= 5.5";

bpmnconceptsLowerCase2 = bpmnconcepts2.toLowerCase();

istarconcepts2 = "iStar-2 Graduation project facilitator Student Graduation supervisor Graduation coordinator Define topic Define research project Thesis topic Supervise intern Thesis topic Approve research project Thesis topic Thesis topic approved Submit thesis timely Write long proposal Write final manuscript Grade student Grade Prepare graduation Good grade for thesis Write a research paper Supervise student Thesis manuscript Present in the colloquium Give diploma Diploma Presentation Manage colloquium D D D D D D And And Help D D And Help Help D D D D D D";

istarconceptsLowerCase2 = istarconcepts2.toLowerCase();

model42 = "Utrecht University Student External company Supervisor MBI coördinator Student administration Room coördinator Decline topic Sign graduation request Reject graduation request Sign workplace agreement Review formal graduation request Approve formal graduation request Solve problems Review chosen topic Approve topic Review graduation request Arrange room Ready to start graduation process Find a supervisor Enroll in colloquium course Create graduation request Find a topic Sign graduation request Write thesis at university Sign workplace agreement Choose project facilitator Write thesis at company Formalize graduation request Enroll in INFOMMBI1 Execute Phase 1 Execute Phase 2 Enroll in INFOMMBI2 Set graduation date Ask for ECTS Ask for room Deliver printed copies to supervisors Attend graduation ceremony Publish thesis at Osiris Defense presentation Provide assessment form Attend 12 colloquia Present thesis during 2 colloquia Greduated Sign workplace agreement";

model4LC2 = model42.toLowerCase();

model52 = "Student Registrated for thesis Courses succesfully completed Thesis Finished Write Thesis Graduation supervisor found Thesis Started Graduation project facilitator found Define Topic Topic Chosen Graduation Supervisor Evaluate Topic Graduation Project Facilitator The University Company Project Graduation project Thesis Project Finished Thesis Thesis Find Graduation Supervisor Find/arrange Graduation Project Facilitator Topic Discuss topic";

model5LC2 = model52.toLowerCase();

model62 = "Graduate MBI Topic defined enroll in colloquium Thesis project completed active participation graduation request signed by first supervisor create graduation request sign request formalized graduation request study plan workplace agreement formalize request workplace agreement signed subscribe to mailing list finish part 1 in 3 months finish part 2 in 5 months first presentation second presentation make proposal create report set date for graduation recieve MBI colloquium first supervisor agree with topic sign request O&I group graduation coordinator check request and study plan MBI programme coordinator check request and study plan science research project coordinator sign workplace agreement company supervisor sign workplace agreement MBI colloquium coordinator Define topic request signed request and study plan checked request and study plan checked agreement signed agreement signed";

model6LC2 = model62.toLowerCase();

model72 = "Student MBI Graduated Phase 1 Completed Phase 2 Completed MBI Colloquium Completed 12 Colloquia attended 2 Presentations Given Make Title Make Research Plan Make Literature Review Can lead to interesting scientific insights Give Final Presentation Make Scientific Paper Bi-weekly O&I research colloquium Attended Set-up Completed Enroll in MBI Colloquium Get Graduation Requests Formalize Graduation Request Subscribe to the Mailing List Obtain Workplace Agreement Related Work,Graduation Supervisor Thesis Chapters Reviewed Review Thesis Topic Department Member Graduation Project Facilitator Graduation School of Natural Sciences Make Thesis Report Define a Topic";

model7LC2 = model72.toLowerCase();

model82 = "University Company Supervisor Student Start MBI thesi Find topic Enroll in colloquium Confirm meeting Company or university Arrange meeting with supervisor Message company Arrange supervisor Confirm topic with company Write graduation request Sign request Sign request Formalise request Subscribe to mailing Submit thesis proposal Check proposal against GSNS form Mark proposal Voldaan Niet voldaan Inform student of retake Niet voldaan + retake niet voldaan Inform student of pass Inform student of failure Voldaan niet voldaan Write retake Attend colloquium meetings Give first presentation Start second phase Conduct research Write report Write thesis proposal Give presentation yes Grade no Write scientific paper Submit reports and papers Attend colloquium meetings Check attendance Attendance status 12 meetings Inform student of fail 12 meetings Grade report Inform student of grade 4 6 4 OR 6 and retake 6 6 Wrap up project Write retake Failure Graduate 8.5 Graduate cum laude Wrap up project and publish paper Decide on topic ";

model8LC2 = model82.toLowerCase();

model92 = "Student Graduate Pass Courses Complete Colloqia requirement Complete MBI Thesis Project Thesis Writing Thesis Defining topic Complete First Phase Complete Second Phase Enrolling in osiris Attending Colloqia Define Research Plan Performing Research Short Proposal Doing literature study Present Thesis Present Project proposal Defending Thesis Get date Get room Evaluating every presentation Attending graduation ceremony Publicate scientific paper Complete work-placement agreementSupervisor Supervising thesis project Do research Grade Thesis project Fill in assesment form GSNS Monitoring student progress External supervisor Asking updates about student Find common interest Discussing Thesis Agree on thesis project";

model9LC2 = model92.toLowerCase();

model102 = "Departement member Supervise Thesis grading within 8 months Coordinator Check proposal Staff members Students Thesis projects Graduate Choose thesis subject Enroll colloquium graduation request Workplace agreement Workplace agreement Thesis Research plan Literature review Title Presentation 2 Presentation1 Meetings Participate 12 meetings Assemble proposal document Study plan Grade thesis Meet";

model10LC2 = model102.toLowerCase();

model112 = "Student Graduated Set up completed First phase completed Second phase completed Wrap up completed Define a topic Enroll MBI colloquium Write graduation request Formalize graduation request Subscribe to mailing list Undefined form Signed graduation request Study plan Signed workplace agreement Define research method Conduct scientific survey Research plan designed and developped Relevant literature understood Give colloquium presentation Well timed Execute research design plan Give colloquium presentation Give final presentation Succesful Set date Ask MBI colloquium Arrange room and beamer Deliver copies to supervisors Printed copies Defend thesis Publish thesis Attend graduation ceremony Cum laude completed Obtain grade higher than 8.5 First supervisor Graduation request template Grade project Graduation supervisor MBI programme coordinator Graduation request signed Write graduation request Sign graduation request Check proposal Check proposal Comunicate results Approve thesis Approve thesis Assesment form";

model11LC2 = model112.toLowerCase();

model122 = "Student Graduated Proposal Phase succesfully completed Thesis phase successfully completed Project idea selected Select project idea Original idea be MBI enrolled MBI program successfully completed Signed graduation request Write graduation request Work placement agreement signed Sign work placement agreement High grade Proposal written Write proposal Contains required elements Relevant literature recorded Find relevant literature Presentation done Create presentation Within 3 month timeframe Cum laude graduation Second presentation done Research done Thesis written Project idea Do research Results Thesis approved Learning goals University Graduation supervisor Project facilitator Sign work placement agreement Graduation coordinator Sign work placement agreement Predeveloped idea Company proposed idea Propose project idea Send graduation request Coordinator-signed agreement Company-signed agreement Approve thesis";

model12LC2 = model122.toLowerCase();

model132 = "Student Utrecht University External project facilitator Decline received Look at staff members webpages Look at staff members Google Scholar pages Look at MBI Grad Projects website Talk to graduation coordinator Select supervisor Arrange meetings with staff members Send request to supervisor Enroll in MBI colloquium Acceptation received Write proposal document Send supervisor sign request Modify proposal document Sign proposal document Deline received Signed proposal document received Arrange work placement Find department member Apply for internship at company Supervisor Internal project facilitator Assess student Decline student Notify student about decline Notify student about acceptation Accept student Request received Sign request received Assess proposal document Accept proposal document Decline proposal document Notify student about decline Sign proposal document Send proposal document back Application received Assess student Accept student Decline student Invite for interview Send decline notification";

model13LC2 = model132.toLowerCase();

model142 = "Student Graduation achieved Set up phase completed Second phase completed First phase completed Enrolled in colloquium Graduation request formalized Mailing list subscribed Define first topic Enroll in colloquium Write graduation request Assemble Sign Formalize graduation request Define research method Conduct literature survey Complete proposal Create title Create research plan University Company Graduation coordinator Check proposal Check studyplan Project facilitator First supervisor Agree with first topic Sign graduation request Assemble Sign Department of Information and Computing Sciences MBI programme coordinator Check studyplan Check proposal First topic defined Graduation request fulfilled Short proposal assembled Short porposal signed Studyplan Proposal";

model14LC2 = model142.toLowerCase();

model152 = "Student First Supervisor Arrange meeting with Staff Members Arrange meeting with Graduation Coordinator Approach organisation for internship Define a Topic Enroll in MBI Colloquium Create Short Proposal with superviser Sign Short Proposal Send Short Proposal to Superviser Recieve Signed Short Proposal Fill in and sign Workplace Agreement Formalise Graduation Request Subscribe to mailing list Participate in Colloquiums Literary Research Ask Supervisor for permission to present Create slides for presentation Send slides to supervisor for approval Present in Colloquim Receive approval Student needs to redo project proposal Courses successfully completed Student can start phase 2 Participate in Colloquiums Start phase 2 Ask supervisor for permission to present Create presentation slides Ask for approval of slides Receive permission to present Present in colloquium Continue Phase 2 Create final presentation Set Date for presentation Date picked Ask for Colloquium EC Arrange room and beamer Deliver printed copies of thesis to supervisors Give final presentation Publish Thesis Attend Graduation Ceremony Agree on Topic ign Short Proposal Judge if student is ready to present Disprove presenting Approve presenting Judge presentation slides Slides disproved Agree on judgement with second supervisor Communicate results to GSNS Student has failed part 1 Student has passed part 1 Slides approved Judge if student is ready to present Disprove presenting Approve presenting Judge Slides Slides disproved Slides approved Judge Presentation Presentation was sufficient Presentation was insufficient With second supervisor, agree or disagree on date Date not agreed on Date agreed on Judge final presentation Student has failed and can't retake Student has failed and can retake Student has passed";

model15LC2 = model152.toLowerCase();

model162 = "Student Supervisor Coordinators Start Find supervisor Settle on topic Choose topic MBI Colloquium enrollment Write graduation request Sign graduation request Send graduation request Receive signed graudation request Conduct project within UU Conduct project outside UU Sign workplace agreement Get workplace agreement signed Submit graduation request Subscribe to the mailing list Define research method Conduct a scientific survey of relevant literature Give presentation in the MBI Colloquium Execute research method Second MBI Colloquium presentation Final MBI Colloquium presentation Have thesis approved Set graduation date/time and check with supervisors Ask for MBI Colloquium EC Arrange location and beamer Deliver printed copy of thesis to supervisors Send out thesis assessment form Defend thesis during presentation Publish thesis on Osiris Participate in graduation ceremony Agree on topic Sign graduation request Give feedback to student Receive proposal and study plan Check study plan Check proposal Issues found No issues found Student notified Pass on data to student administration";

model16LC2 = model162.toLowerCase();

model172 = "MBI Graduation Project Student First supervisor Graduation coordiantor(s) MBI Coordinator Second supervisor Define topic Sure about topic Contact graduation coordinator Find suiting topic Find supervisor Yes No Enroll MBI colloquiem Start graduation request Write graduation request Sign 1st signature Sign 2nd signature Support student Send to coordinators Check graduation request Agreed? Check proposal graduation request Agreed? Subscribe mailing list Start phase one Define research method Conduct scientific survey Give 1st presentation Grade presentation Share judgement Agreed? Inform approval Yes No Inform rejection Create GSNS form Send to GSNS Sent to student Receive feedback 1st presentation Work on thesis Give 2nd presentation 4 months Continue thesis Finish thesis report Give final presentation Give 1st grade";

model17LC2 = model172.toLowerCase();

model182 = "Utrecht University Supervisor(s) Student MBI colloquium coordinator Geraldine LeeBeek Find Supervisor Give topic Review topic Decline topic and student Give appraisal Approve Receive appraisal Start phase one Define research method Define scientific survey of the literature Send to supervisor for remarks Review student work of phase one Mark phase one as Voldaan Organize Phase one Presentations Send review to student Receive review Make presentation Phase one Write down feedback of presentation Give Phase one presentation Give results/feedback of presentation to student Receive presentation feedback Start phase two Start working on thesis research Gather results Organize presentation phase two Make presentation phase two Give presentation phase 2 Write down feedback of presentation Give results/feedback to student Receive feedback Resume thesis research Gather results Start organizing final presentation Make final presentation Perform final presentation Write down feedback of presentation Give results/feedback to student Receive feedback Write final report Hand in final report Grade final report Send grade to student Finish phase two Receive grade of report Declare day of graduation Agreement of date by supervisors Send room/beamer reservation Agreement No agreement Send request MBI Colloquium Receive request Receive reservation Inform student Grant 4 EC to student Receive message";

model18LC2 = model182.toLowerCase();

model192 = "Utrecht University Company Student First Supervisor Science Research Project Coordinator MBI programme coordinator Graduation coordinator Graduation supervisor Start Complete courses Find supervisor Sure about topic? Yes No Arrange meeting with graduation coordinator Define topic Agree on topic Enroll in colloquium Write graduation request Send graduation request to first supervisor Sign graduation request Sign graduation request Find workspace Workspace outside Utrecht University? No Fill in work placement agreement Send agreement Sign agreement Sign agreement Fill in formalisation form Check proposal Check proposal Any issues? Yes Pass data to Student Administration Subscribe to mailinglist No Start first phase Define research method Conduct scientific survey Present phase 1 in MBI colloquium Grade phase 1 Fill in GSNS form Give feedback Grade phase 1 Fill in GSNS form Give feedback Agree on grading Agree on grading Communicate grading to GSNS Start second phase Execute research Present in MBI colloquium Make final presentation Grade second phase Grade second phase Pass second phase Supervisor Sign agreement";

model19LC2 = model192.toLowerCase();





//Concept lists of not useful elements

model4NU = "research plan\n standard contract\n work placement agreement\n project idea\n idea\n pre-developed project\n topic\n thesi topic\n side project\n part-time job\n part-time thesi\n token\n participation token\n presentation\n oeni\n oeni group\n utrecht university\n uu\n scientific paper\n publication\n official ceremony\n cum-laude\n cum-laude graduation\n calendar\n google calendar\n research colloquium\n oeni research colloquium\n thesi colloquium\n grade\n grading\n systematic literature study\n relevant literature\n related work\n literature review\n second part\n second phase\n project proposal\n infommbi1\n first phase\n research approach\n envisaged method\n graduation project facilitator\n short proposal\n graduation request\n gsn\n graduate school\n learning outcome\n ilo\n computing science\n computer science\n mbi program\n mbi\n information science\n staff member\n department member\n final thesi project\n mbi thesi project\n mbi thesi\n mbi graduation project\n graduation project\n project\n thesi project\n thesi\n elementlabel";

model4NULC = model4NU.toLowerCase();

model5NU = "second part\n infommbi2\n second phase\n infommbi1\n research approach\n proposed research method\n envisaged method\n project facilitator\n gsn\n graduate school\n learning outcome\n ilo\n intended learning outcome\n computing science\n computer science\n mbi program\n mbi\n information science\n staff member\n department member\n supervisor\n final thesi project\n mbi thesi project\n mbi thesi\n mbi graduation project\n elementlabel";

model5NULC = model5NU.toLowerCase();

model6NU = "mbi\n information science\n final thesi project\n mbi thesi project\n mbi thesi\n graduation project\n project\n thesi";

model6NULC = model6NU.toLowerCase();

model7NU = "mbi colloquium\n grade\n grading\n systematic literature study\n relevant literature\n literature review\n second part\n infommbi2\n second phase\n phase two\n project proposal\n infommbi1\n first phase\n phase one\n research approach\n proposed research method\n short proposal\n gsn\n graduate school\n learning outcome\n ilo\n intended learning outcome\n computing science\n computer science\n mbi program\n final thesi project\n mbi thesi project\n mbi thesi\n project\n thesi project\n thesi\n elementlabel";

model7NULC = model7NU.toLowerCase();

model8NU = "topic\n thesi topic\n part-time thesi\n token\n participation token\n presentation\n oral presentation\n oeni\n oeni group\n utrecht university\n uu\n scientific paper\n evaluation form\n assessment form\n defense\n thesi defense\n calendar\n google calendar\n systematic literature study\n relevant literature\n related work\n literature review\n second part\n infommbi2\n second phase\n phase two\n project proposal\n infommbi1\n research approach\n proposed research method\n envisaged method\n graduation project facilitator\n project facilitator\n short proposal\n graduation request\n gsn\n graduate school\n learning outcome\n ilo\n computing science\n computer science\n mbi program\n mbi\n information science\n staff member\n department member\n graduation supervisor\n supervisor\n final thesi project\n mbi thesi project\n mbi thesi\n mbi graduation project\n graduation project\n project\n thesi project\n thesi\n elementlabel";

model8NULC = model8NU.toLowerCase();

model9NU = "idea\n pre-developed project\n topic\n thesi topic\n side project\n part-time job\n part-time thesi\n token\n participation token\n presentation\n oral presentation\n oeni\n oeni group\n utrecht university\n uu\n scientific paper\n publication\n official ceremony\n evaluation form\n defense\n thesi defense\n cum-laude\n cum-laude graduation\n calendar\n google calendar\n research colloquium\n oeni research colloquium\n thesi colloquium\n mbi colloquium\n grade\n systematic literature study\n relevant literature\n related work\n literature review\n second part\n infommbi2\n second phase\n phase two\n infommbi1\n first phase\n phase one\n research approach\n proposed research method\n envisaged method\n graduation project facilitator\n project facilitator\n short proposal\n gsn\n graduate school\n learning outcome\n ilo\n intended learning outcome\n computing science\n computer science\n mbi program\n mbi\n information science\n staff member\n department member\n graduation supervisor\n supervisor\n final thesi project\n mbi thesi\n mbi graduation project\n graduation project\n project\n thesi project\n thesi\n elementlabel";

model9NULC = model9NU.toLowerCase();

model10NU = "envisaged method\n graduation project facilitator\n project facilitator\n gsn\n graduate school\n learning outcome\n ilo\n computing science\n computer science\n mbi program\n mbi\n information science\n graduation supervisor\n supervisor\n final thesi project\n mbi thesi project\n mbi thesi\n mbi graduation project\n graduation project\n project\n thesi\n elementlabel";

model10NULC = model10NU.toLowerCase();

model11NU = "intended learning outcome\n publication\n oral presentation\n research approach\n envisaged method\n thesi colloquium\n information science\n graduate school\n pre-developed project\n grading\n uu\n mbi thesi\n final thesi project\n short proposal";

model11NULC = model11NU.toLowerCase();

model12NU = "part-time thesi\n information science\n systematic literature study\n mbi\n defense\n computer science\n mbi program\n computing science\n project";

model12NULC = model12NU.toLowerCase();

model13NU = "second part\n uu\n phase one\n oeni group\n project";

model13NULC = model13NU.toLowerCase();

model14NU = "grading\n proposed research method\n literature review\n research approach\n uu\n publication\n oeni\n gsn\n project idea\n graduation project facilitator\n phase two\n graduation request\n project proposal\n elementlabel\n work placement agreement\n pre-developed project\n learning outcome\n oral presentation\n related work\n ilo\n grade\n computer science\n side project\n assessment form\n topic\n participation token\n defense\n relevant literature\n plan\n infommbi1\n evaluation form\n staff member\n graduation supervisor\n mbi thesi\n scientific paper\n short proposal";

model14NULC = model14NU.toLowerCase();

model15NU = "supervisor\n publication\n topic\n mbi thesi project\n infommbi2\n oeni research colloquium\n department member\n side project\n project proposal\n envisaged method\n oeni group\n oeni\n thesi topic\n part-time thesi\n learning outcome";

model15NULC = model15NU.toLowerCase();

model16NU = "first phase\n mbi thesi\n phase one\n token\n calendar";

model16NULC = model16NU.toLowerCase();

model17NU = "standard contract\n side project\n participation token\n elementlabel\n cum-laude\n scientific paper\n graduation supervisor\n project proposal\n cum-laude graduation\n thesi topic\n grade\n phase two\n thesi project\n oeni";

model17NULC = model17NU.toLowerCase();

model18NU = "staff member\n google calendar\n mbi colloquium\n oeni";

model18NULC = model18NU.toLowerCase();
