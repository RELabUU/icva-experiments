# Research

Research work mentioning the piStar tool.

*Is your work missing here? Add a pull request or send me the information through jhcp at cin.ufpe.br*

- SCHUETZ, Christoph G.; SCHREFL, Michael. Towards Formal Strategy Analysis with Goal Models and Semantic Web Technologies. In: International Conference on Conceptual Modeling. Springer, Cham, 2017. p. 144-153.
[https://link.springer.com/chapter/10.1007/978-3-319-70625-2_14]

- LI, Tong; GRUBB, Alicia M.; HORKOFF, Jennifer. Understanding Challenges and Tradeoffs in iStar Tool Development. In: iStar. 2016. p. 49-54.
[http://ceur-ws.org/Vol-1674/iStar16_pp49-54.pdf]

- RUIZ, Marcela; AYDEMIR, Fatma Başak; DALPIAZ, Fabiano. Using Conceptual Models in Research Methods Courses: An experience using iStar 2.0.
[http://ceur-ws.org/Vol-1954/istarT_2017_paper_2.pdf]
