# iStar tool including suggestion service
## General information
This tool is created for a bachelor's thesis by Milo Plomp. It is an extension of an open source iStar modeling tool.

## Base tool
The base of this tool is [piStar](https://github.com/jhcp/pistar).

## How to use
All changes are made in tool/index.html and tool/js/custom.js

To run the tool, open the main directory in a terminal and run the following command to set up a server:
```
http-server -c-1
```

Some issues might arise due to resource conflict when running the tool. For the experiments, we used a CORS browser extension.
