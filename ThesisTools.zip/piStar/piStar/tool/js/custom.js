//The json object to which feedback is pushed
var obj;

//Variable with all feedback info
var allFeedback = {
  "model": {
     "experimentNumber": expNumber,
     "language": "iStar"
   },
   "feedback": [
  ]
};

//Variable determining if feedback is given
var feedbackGiven;

//Array of suggestions in the suggestion file
var idArray;

//Log model to console
var logModel = function(){
  console.log(saveModel());
};

//The suggestion file object
var JSONObject;

//Experiment number filled in by observer
var expNumber;

//Simplified JSON commit file
var simplifiedJSONfile;

//Empty JSON file for requesting suggestions
var emptyJSON = {
};

//Display suggestions on screen
var giveSuggestions = function() {

  //Create the simplified JSON file for committing
  simplifyJSON();

  //Committing the simplified JSON file
  var req = new XMLHttpRequest();
  var url = "http://pacas.science.uu.nl:8080/ozpplomp/"+expNumber+"/commit/";
  req.open("POST", url, true);
  req.send(JSON.stringify(simplifiedJSONfile));

  //When the commit file is sent
  req.onreadystatechange = function() {//Call a function when the state changes.
  if(req.readyState == 4 && req.status == 200) {

      //Request the suggestion file
      var sugreq = new XMLHttpRequest();
      var sugurl = "http://pacas.science.uu.nl:8080/ozpplomp/"+expNumber+"/suggestions/";
      sugreq.open("POST", sugurl, true);
      sugreq.send(JSON.stringify(emptyJSON));

      //When the suggestion file is received
      sugreq.onreadystatechange = function() {//Call a function when the state changes.
      if(sugreq.readyState == 4 && sugreq.status == 200) {
          JSONObject = JSON.parse(sugreq.responseText);
          suggestions();

          //show the div and change button text
          $('#suggestionDiv').show();
          $('#suggTitle').show();
          document.getElementById("giveSuggestions").innerHTML = "Update suggestions";
        }
      }
    }
  }
};

function suggestions() {
  var suggestionTable = document.getElementById("suggestionList");
  idArray = JSONObject.suggestions;

  //Delete all rows, starting from position 1
  if(suggestionTable.rows.length > 1) {
    suggestionTable.innerHTML="<table id=\"suggestionList\"><thead><tr class=\"tableHead\"><th id=\"tableSuggestion\">Suggestion</th><th id=\"tableUseful\">Useful?</th></tr></thead><tbody></tbody></table>";
  }

  if (JSONObject.suggestions.length > 0) {
    for (var i = 0; i < JSONObject.suggestions.length; i++) {

      //Insert rows for all suggestions in JSON file
      var row = suggestionTable.insertRow(i+1);
      var cell = row.insertCell(0);
      var cell2 = row.insertCell(1);
      var cell3 = row.insertCell(2);
      cell.innerHTML = JSONObject.suggestions[i].suggestionName;
      cell2.innerHTML =
      '<button id="usefulBttn">Useful</button>';
      cell3.innerHTML =
      '<button id="notUsefulBttn">Not useful</button>';
    }
  }
  else {
    var row = suggestionTable.insertRow(1);

    row.innerHTML = "<tr><td colspan=\"2\">There are no suggestions.</td></tr>";
  }

  //React to click events for second column (positive)
  $( "tr" ).each(function( index ) {
    $( this ).find( "td:eq(1) > button" ).click(function(event) {
      //Get the row in which the button is located
      var row = event.target.parentNode.parentNode;
      //Get the content of the first cell in that row
      var cel = row.cells[0];
      var suggestionName = cel.innerHTML;
      var rowIndex = row.rowIndex;
      var suggID = idArray[rowIndex-1].suggestionid;
      feedbackPos(suggestionName, rowIndex, suggID);

      if(JSONObject.suggestions.length == 0)
      {
        var row = suggestionTable.insertRow(1);
        row.innerHTML = "<tr><td colspan=\"2\">There are no suggestions.</td></tr>";
      }
    });
  });

  //React to click events for third column (negative)
  $( "tr" ).each(function( index ) {
    $( this ).find( "td:eq(2) > button" ).click(function(event) {
      //Get the row in which the button is located
      var row = event.target.parentNode.parentNode;
      //Get the content of the first cell in that row
      var cel = row.cells[0];
      var suggestionName = cel.innerHTML;
      var rowIndex = row.rowIndex;
      var suggID = idArray[rowIndex-1].suggestionid;
      feedbackNeg(suggestionName, rowIndex, suggID);

      if(JSONObject.suggestions.length == 0)
      {
        var row = suggestionTable.insertRow(1);
        row.innerHTML = "<tr><td colspan=\"2\">There are no suggestions.</td></tr>";
      }
    });
  });
}

//Update the expNumber variable
$('#numberOk').click(function(e) {
  expNumber = (document.querySelector("#experimentNumber")).value;

  //Disable elements
  $( "#numberOk" ).css({"disabled": "true", "display": "none"});
  $( "#experimentNumber" ).prop( "disabled", true );
});

function pastFeedback(obj) {
  var pastSuggestionTable = document.getElementById("pastSuggestionList");
  var test = obj;

  //If there is at least 1 feedback result
  if (feedbackGiven == "yes") {
    //Delete content of table
    pastSuggestionTable.innerHTML="<table id=\"pastSuggestionList\"><thead><tr class=\"tableHead\"><th id=\"tableSuggestion\">Suggestion</th><th id=\"pastFeedback\">Rated</th></tr></thead><tbody></tbody></table>";

    for (var i = 0; i < allFeedback.feedback.length; i++) {
      var buttonID;
      if(allFeedback.feedback[i].feedback == "useful"){
        buttonID = "posFeedback";
      }
      else {
        buttonID = "negFeedback";
      }

      //Insert rows for all suggestions in JSON file
      var row = pastSuggestionTable.insertRow(i+1);
      var cell = row.insertCell(0);
      var cell2 = row.insertCell(1);
      cell.innerHTML = allFeedback.feedback[i].suggestionName;
      //cell2.innerHTML = obj.feedback[i].feedback;
      cell2.innerHTML = '<button id='+buttonID+'>'+allFeedback.feedback[i].feedback+'</button>';
    }
  }
  else {
    //Delete all rows, starting from position 1
    if(pastSuggestionTable.rows.length > 1) {
      for(var j = 0; j < pastSuggestionTable.rows.length; j++){
        pastSuggestionTable.deleteRow(1);
      }
    }
    var row = pastSuggestionTable.insertRow(1);
    var cell = row.insertCell(0);
    row.innerHTML = "<tr><td colspan=\"2\">No suggestions have been rated yet.</td></tr>";
  }
}

//Display suggestions on screen
$('#pastSuggestions').click(function(e) {
  if(document.getElementById("pastSuggestions").innerHTML == "View past suggestions"){
    //show the div and change button text
    $('#pastSuggDiv').show();
    document.getElementById("pastSuggestions").innerHTML = "Hide past suggestions";
    pastFeedback();
  }
  else {
    //hide the div and change button text
    $('#pastSuggDiv').hide()
    document.getElementById("pastSuggestions").innerHTML = "View past suggestions";
  }
});

function feedbackPos(name, rowindex, suggID) {
  //Writing feedback to historic feedback JSON
  allFeedback.feedback.push({"suggestionId": suggID, "suggestionName": name, "feedback": "useful"});

  feedbackGiven = "yes";

  //Send a new JSON file for every feedback element
  obj = {
    "model": {
       "experimentNumber": expNumber,
       "language": "iStar"
     },
     "feedback": [
       {
         "suggestionId": suggID,
         "suggestionName": name,
         "feedback": "useful"
       }
    ]
  };

  var json = JSON.stringify(obj, null, 4);

  //removing id from array
  idArray.splice(rowindex-1, 1);

  //removing suggestion from screen
  var suggestionTable = document.getElementById("suggestionList");
  suggestionTable.deleteRow(rowindex);

  //sending feedback info to service
  var feedbackreq = new XMLHttpRequest();
  var feedbackurl = "http://pacas.science.uu.nl:8080/ozpplomp/"+expNumber+"/feedback/";
  feedbackreq.open("POST", feedbackurl, true);
  feedbackreq.send(json);

  //pushing suggestion to past suggestion table
  var pastSuggestionTable = document.getElementById("pastSuggestionList");
  var row = pastSuggestionTable.insertRow(0);
  var cell = row.insertCell(0);
  var cell2 = row.insertCell(1);

  pastFeedback(obj);
}

function feedbackNeg(name, rowindex, suggID) {
  //Writing feedback to historic feedback JSON
  allFeedback.feedback.push({"suggestionId": suggID, "suggestionName": name, "feedback": "not useful"});

  feedbackGiven = "yes";

  obj = {
    "model": {
       "experimentNumber": expNumber,
       "language": "iStar"
     },
     "feedback": [
       {
         "suggestionId": suggID,
         "suggestionName": name,
         "feedback": "not useful"
       }
    ]
  };

  var json = JSON.stringify(obj, null, 4);

  //removing id from array
  idArray.splice(rowindex-1, 1);

  //removing suggestion from screen
  var suggestionTable = document.getElementById("suggestionList");
  suggestionTable.deleteRow(rowindex);

  //sending feedback info to service
  var feedbackreq = new XMLHttpRequest();
  var feedbackurl = "http://pacas.science.uu.nl:8080/ozpplomp/"+expNumber+"/feedback/";
  feedbackreq.open("POST", feedbackurl, true);
  feedbackreq.send(json);

  pastFeedback();
}

function simplifyJSON() {
  var xmlModel = saveModel();

  //Make sure the model is updated before this function can be called
  if(xmlModel == null){
    alert("You have to update the model before requesting suggestions!")
  }
  //This part of the code is only executed when the model is updated first
  else if(xmlModel != null){

    var modelObject = JSON.parse(xmlModel);
    var modelString = JSON.stringify(modelObject, ['actors', 'nodes', 'dependencies', 'links', 'id', 'text', 'label'], 4);

    var arrayofLines = modelString.split("\n");

    //Output of simplified
    var simplifiedJSONstring = "";
    //simplified JSON file to which every element is pushed
    simplifiedJSONfile = {
      "elements": [
      ]
    };

    for(var i = 0; i < (arrayofLines.length - 1); i++)
    {
      var condition1 = arrayofLines[i].includes("id");
      var condition2 = arrayofLines[i+1].includes("text");
      var condition3 = arrayofLines[i+1].includes("label");

      if(condition1 && (condition2 || condition3))
      {
        var string1 = arrayofLines[i];
        var string2 = arrayofLines[i+1];

        simplifiedJSONstring += string1 + "\n" + string2 + "\n";

        //Remove unwanted string info
        var splitString1 = string1;
        splitString1 = splitString1.trim();
        splitString1 = splitString1.replace(" ","");
        splitString1 = splitString1.replace(/\"id\":/g,'');
        splitString1 = splitString1.replace(/,/g,'');
        splitString1 = splitString1.replace(/\"/g,'');

        var splitString2 = string2;
        splitString2 = splitString2.trim();
        splitString2 = splitString2.replace(" ","");
        splitString2 = splitString2.replace(/\"text\":/g,'');
        splitString2 = splitString2.replace(/\"label\":/g,'');
        splitString2 = splitString2.replace(/,/g,'');
        splitString2 = splitString2.replace(/\"/g,'');

        simplifiedJSONfile.elements.push({"id": splitString1, "name": splitString2});

      }
    }
    console.log(JSON.stringify(simplifiedJSONfile, null, 4));
  }
}
