//barebones
$(document).ready(function(){
    istar.setupModel();
    istar.setupMetamodel(istarcoreMetamodel);
});

// graphical
// $(document).ready(function(){
//     istar.setupModel();
//     istar.setupDiagram();
//     istar.setupMetamodel(istarcoreMetamodel);
//     ui.defineInteractions();
//     //wikiExample();
//     elementsExample();
// });
