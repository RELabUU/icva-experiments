# istarcore

This is the library created for and used by the piStar tool. It aims to provide basic and extendable, non-UI functionalities for any developer that wants to develop a javascript-based goal model tool, either on the browser or not. It may spin-off to its own project in the future.

## Dependencies

This library depends on JointJS. JointJS depends on:
 - backbone
 - jquery
 - lodash
