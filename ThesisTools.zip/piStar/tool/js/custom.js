//The json object to which feedback is pushed
var obj = {
    "feedback": [
  ]
};

var idArray;

//Log model to console
var logModel = function(){
  console.log(saveModel());
};


//Display suggestions on screen
var giveSuggestions = function() {
  if(document.getElementById("giveSuggestions").innerHTML == "Give suggestions"){
    //Loading suggestions JSON file
    var JSONObject;
    var req = new XMLHttpRequest();
    req.open("GET", "/../models/suggestions_milo.json", true);
    req.addEventListener("load", transferComplete);
    req.send();

    //When file is loaded, add it to variable
    function transferComplete(e){
      JSONObject = JSON.parse(req.responseText);
    }

    //show the div and change button text
    $('#suggestionDiv').show();
    $('#suggTitle').show();
    document.getElementById("giveSuggestions").innerHTML = "Update suggestions";
    suggestions();
  }
  else {
    //Loading suggestions JSON file
    var JSONObject;
    var req = new XMLHttpRequest();
    req.open("GET", "/../models/suggestions_milo.json", true);
    req.addEventListener("load", transferComplete);
    req.send();

    //When file is loaded, add it to variable
    function transferComplete(e){
      JSONObject = JSON.parse(req.responseText);
    }

    suggestions();
  }
};

function suggestions() {
  var suggestionTable = document.getElementById("suggestionList");
  idArray = JSONObject.suggestions;

  if (JSONObject.suggestions.length > 0) {
    for (var i = 0; i < JSONObject.suggestions.length; i++) {
      //Delete all rows, starting from position 1
      if(suggestionTable.rows.length > i+1) {
        for(var j = 0; j < suggestionTable.rows.length; j++){
          suggestionTable.deleteRow(1);
        }
      }

      //Insert rows for all suggestions in JSON file
      var row = suggestionTable.insertRow(i+1);
      var cell = row.insertCell(0);
      var cell2 = row.insertCell(1);
      var cell3 = row.insertCell(2);
      cell.innerHTML = JSONObject.suggestions[i].suggestionName;
      cell2.innerHTML =
      '<button id="usefulBttn">Useful</button>';
      cell3.innerHTML =
      '<button id="notUsefulBttn">Not useful</button>';
    }
  }
  else {
    //Delete all rows, starting from position 1
    if(suggestionTable.rows.length > 1) {
      for(var j = 0; j < suggestionTable.rows.length; j++){
        suggestionTable.deleteRow(1);
      }
    }
    var row = suggestionTable.insertRow(1);

    row.innerHTML = "<tr><td colspan=\"2\">There are no suggestions.</td></tr>";
  }

  //React to click events for second column (positive)
  $( "tr" ).each(function( index ) {
    $( this ).find( "td:eq(1) > button" ).click(function(event) {
      //Get the row in which the button is located
      var row = event.target.parentNode.parentNode;
      //Get the content of the first cell in that row
      var cel = row.cells[0];
      var suggestionName = cel.innerHTML;
      var rowIndex = row.rowIndex;
      var suggID = idArray[rowIndex-1].suggestionid;
      feedbackPos(suggestionName, rowIndex, suggID);

      if(JSONObject.suggestions.length == 0)
      {
        var row = suggestionTable.insertRow(1);
        row.innerHTML = "<tr><td colspan=\"2\">There are no suggestions.</td></tr>";
      }
    });
  });

  //React to click events for third column (negative)
  $( "tr" ).each(function( index ) {
    $( this ).find( "td:eq(2) > button" ).click(function(event) {
      //Get the row in which the button is located
      var row = event.target.parentNode.parentNode;
      //Get the content of the first cell in that row
      var cel = row.cells[0];
      var suggestionName = cel.innerHTML;
      var rowIndex = row.rowIndex;
      var suggID = idArray[rowIndex-1].suggestionid;
      feedbackNeg(suggestionName, rowIndex, suggID);

      if(JSONObject.suggestions.length == 0)
      {
        var row = suggestionTable.insertRow(1);
        row.innerHTML = "<tr><td colspan=\"2\">There are no suggestions.</td></tr>";
      }
    });
  });
}

function pastFeedback() {
  var pastSuggestionTable = document.getElementById("pastSuggestionList");

  //If there is at least 1 feedback result
  if (obj.feedback.length > 0) {
    //Delete content of table
    pastSuggestionTable.innerHTML="<table id=\"pastSuggestionList\"><thead><tr class=\"tableHead\"><th id=\"tableSuggestion\">Suggestion</th><th id=\"pastFeedback\">Rated</th></tr></thead><tbody></tbody></table>";

    for (var i = 0; i < obj.feedback.length; i++) {
      var buttonID;
      if(obj.feedback[i].feedback == "useful"){
        buttonID = "posFeedback";
      }
      else {
        buttonID = "negFeedback";
      }

      //Insert rows for all suggestions in JSON file
      var row = pastSuggestionTable.insertRow(i+1);
      var cell = row.insertCell(0);
      var cell2 = row.insertCell(1);
      cell.innerHTML = obj.feedback[i].suggestionName;
      //cell2.innerHTML = obj.feedback[i].feedback;
      cell2.innerHTML = '<button id='+buttonID+'>'+obj.feedback[i].feedback+'</button>';
    }
  }
  else {
    //Delete all rows, starting from position 1
    if(pastSuggestionTable.rows.length > 1) {
      for(var j = 0; j < pastSuggestionTable.rows.length; j++){
        pastSuggestionTable.deleteRow(1);
      }
    }
    var row = pastSuggestionTable.insertRow(1);
    var cell = row.insertCell(0);
    //var cell2 = row.insertCell(1);
    row.innerHTML = "<tr><td colspan=\"2\">No suggestions have been rated yet.</td></tr>";
  }
}

//Display suggestions on screen
$('#pastSuggestions').click(function(e) {
  if(document.getElementById("pastSuggestions").innerHTML == "View past suggestions"){
    //show the div and change button text
    $('#pastSuggDiv').show();
    document.getElementById("pastSuggestions").innerHTML = "Hide past suggestions";
    pastFeedback();
  }
  else {
    //hide the div and change button text
    $('#pastSuggDiv').hide()
    document.getElementById("pastSuggestions").innerHTML = "View past suggestions";
  }
});

function feedbackPos(name, rowindex, suggID) {
  //writing feedback to json
  obj.feedback.push({"suggestionid": suggID, "suggestionName": name, "feedback": "useful"});
  var json = JSON.stringify(obj, null, 4);
  alert(json);

  //removing id from array
  idArray.splice(rowindex-1, 1);

  //removing suggestion from screen
  var suggestionTable = document.getElementById("suggestionList");
  suggestionTable.deleteRow(rowindex);

  //pushing suggestion to past suggestion table
  var pastSuggestionTable = document.getElementById("pastSuggestionList");
  var row = pastSuggestionTable.insertRow(0);
  var cell = row.insertCell(0);
  var cell2 = row.insertCell(1);

  pastFeedback();
}

function feedbackNeg(name, rowindex, suggID) {
  //writing feedback to json
  obj.feedback.push({"suggestionid": suggID, "suggestionName": name, "feedback": "not useful"});
  var json = JSON.stringify(obj, null, 4);
  alert(json);

  //removing id from array
  idArray.splice(rowindex-1, 1);

  //removing suggestion from screen
  var suggestionTable = document.getElementById("suggestionList");
  suggestionTable.deleteRow(rowindex);

  pastFeedback();
}

$('#simplifiedJSON').click(function(e) {
  var xmlModel = saveModel();

  //Make sure the model is updated before this function can be called
  if(xmlModel == null){
    alert("You have to update the model before downloading!")
  }
  //This part of the code is only executed when the model is updated first
  else if(xmlModel != null){

    var modelObject = JSON.parse(xmlModel);
    var modelString = JSON.stringify(modelObject, ['actors', 'nodes', 'dependencies', 'links', 'id', 'text', 'label'], 4);

    var arrayofLines = modelString.split("\n");

    //Output of simplified
    var simplifiedJSONstring = "";
    //simplified JSON file to which every element is pushed
    var simplifiedJSONfile = {
      "elements": [
      ]
    };

    for(var i = 0; i < (arrayofLines.length - 1); i++)
    {
      var condition1 = arrayofLines[i].includes("id");
      var condition2 = arrayofLines[i+1].includes("text");
      var condition3 = arrayofLines[i+1].includes("label");

      if(condition1 && (condition2 || condition3))
      {
        var string1 = arrayofLines[i];
        var string2 = arrayofLines[i+1];

        simplifiedJSONstring += string1 + "\n" + string2 + "\n";
        //simplifiedJSONstring += string1 + "\n";

        //Remove unwanted string info
        var splitString1 = string1;
        splitString1 = splitString1.trim();
        splitString1 = splitString1.replace(" ","");
        splitString1 = splitString1.replace(/\"id\":/g,'');
        splitString1 = splitString1.replace(/,/g,'');
        splitString1 = splitString1.replace(/\"/g,'');

        var splitString2 = string2;
        splitString2 = splitString2.trim();
        splitString2 = splitString2.replace(" ","");
        splitString2 = splitString2.replace(/\"text\":/g,'');
        splitString2 = splitString2.replace(/\"label\":/g,'');
        splitString2 = splitString2.replace(/,/g,'');
        splitString2 = splitString2.replace(/\"/g,'');

        simplifiedJSONfile.elements.push({"id": splitString1, "name": splitString2});

      }
    }
    //alert(JSON.stringify(simplifiedJSONfile, null, 4));
    console.log(JSON.stringify(simplifiedJSONfile, null, 4));
  }
});
